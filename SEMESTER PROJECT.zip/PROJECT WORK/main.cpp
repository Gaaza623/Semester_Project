#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Product {
private:
    string name;
    int quantity;
    double price;

public:
    Product(const string& n, int q, double p) : name(n), quantity(q), price(p) {}

    string getName() const {
        return name;
    }

    int getQuantity() const {
        return quantity;
    }

    double getPrice() const {
        return price;
    }

    void updateQuantity(int newQuantity) {
        quantity = newQuantity;
    }

    void updatePrice(double newPrice) {
        price = newPrice;
    }
};

class Inventory {
private:
    vector<Product> products;

public:
    void addProduct(const Product& product) {
        products.push_back(product);
    }

    Product* findProduct(const string& productName) {
        for (vector<Product>::iterator it = products.begin(); it != products.end(); ++it) {
            if (it->getName() == productName) {
                return &(*it);
            }
        }
        return 0; 
    }

    void displayInventory() const {
        cout << "Inventory:\n";
        for (vector<Product>::const_iterator it = products.begin(); it != products.end(); ++it) {
            const Product& product = *it;
            cout << "Name: " << product.getName() << ", Quantity: " << product.getQuantity() << ", Price: $" << product.getPrice() << "\n";
        }
    }
};

int main() {
    Inventory inventory;

    int choice;

    do {
    	cout << "\nShop inventory\n";
        cout << "\nMenu:\n";
        cout << "1. Add product\n";
        cout << "2. Update product\n";
        cout << "3. Display inventory\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string name;
                int quantity;
                double price;

                cout << "Enter product name: ";
                cin >> name;

                cout << "Enter quantity: ";
                cin >> quantity;

                cout << "Enter price: ";
                cin >> price;

                Product product(name, quantity, price);
                inventory.addProduct(product);
                cout << "Product added!\n";
                break;
            }
            case 2: {
                string updateProductName;
                cout << "Enter the name of the product to update: ";
                cin >> updateProductName;

                Product* foundProduct = inventory.findProduct(updateProductName);

                if (foundProduct) {
                    double newPrice;
                    cout << "Enter the new price: ";
                    cin >> newPrice;

                    foundProduct->updatePrice(newPrice);

                    int newQuantity;
                    cout << "Enter the new quantity: ";
                    cin >> newQuantity;

                    foundProduct->updateQuantity(newQuantity);

                    cout << "Product updated!\n";
                } else {
                    cout << "Product not found.\n";
                }
                break;
            }
            case 3:
                inventory.displayInventory();
                break;
            case 4:
                cout << "Exiting the program.\n";
                break;
            default:
                cout << "Invalid choice. Please choose again.\n";
        }
    } while (choice != 4);

    return 0;
}
